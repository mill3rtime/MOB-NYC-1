//
//  Calculator.swift
//  CalculatorM
//
//  Created by Matt Miller on 2/13/15.
//  Copyright (c) 2015 Matt. All rights reserved.
//

import Foundation


class Calculator: NSObject {
    
   var calcyArray = [String]()
    

    func compute() {
        
        //if type is numnber then start {
        
        //[1]
        
        
    }
}