//
//  CalcButton.swift
//  CalculatorM
//
//  Created by Matt Miller on 2/12/15.
//  Copyright (c) 2015 Matt. All rights reserved.
//


//?* want a variable with 3 possibilities: number, operator, clear
//? CHINESE START AND END



import Foundation
import UIKit


// CHINESE STARTS HERE
class CalcButton: UIButton {

    var label: UILabel = UILabel()
    var origColor = UIColor.purpleColor()
    var tapColor:UIColor?
    var type = ""
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    // CHINESE ENDS HERE
    
    func commonInit() {
        self.addSubview(label)
        label.setTranslatesAutoresizingMaskIntoConstraints(false)
        self.addConstraint(NSLayoutConstraint(item: label,
            attribute: .CenterX,
            relatedBy: .Equal,
            toItem: self,
            attribute: .CenterX,
            multiplier: 1,
            constant: 0))
        
        self.addConstraint(NSLayoutConstraint(item: label,
            attribute: .CenterY,
            relatedBy: .Equal,
            toItem: self,
            attribute: .CenterY,
            multiplier: 1,
            constant: 0))
        label.textAlignment = .Center
        label.textColor = UIColor.whiteColor()
        
    }
}
