//
//  ViewController.swift
//  CalculatorM
//
//  Created by Matt Miller on 2/11/15.
//  Copyright (c) 2015 Matt. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {
  
    
    var coolGreen = UIColor(red: 85/255, green: 234/255, blue: 188/255, alpha: 1.0)
    
    
    // OUTLETS FOR BUTTONS
    @IBOutlet weak var one: CalcButton!
    

    
    
    @IBOutlet weak var two: UIView!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
       // FOR LOOP ON YOUR ARRAY OF BUTTONS TO SET COLOR
        
        
        one.backgroundColor = coolGreen
        
        
        
        // Loop to assign numbers to number types
   
        self.one.label.text = "1"
        
        
        
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

