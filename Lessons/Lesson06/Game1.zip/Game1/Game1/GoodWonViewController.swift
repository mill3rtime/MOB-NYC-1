//
//  GoodWonViewController.swift
//  Game1
//
//  Created by Matt Miller on 1/14/15.
//  Copyright (c) 2015 Matt. All rights reserved.
//

import UIKit

class GoodWonViewController: UIViewController {
    
    
    @IBAction func dismiss(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)

        
    }

    
    
}
